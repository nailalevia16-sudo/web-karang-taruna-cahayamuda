<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kegiatan - Karang Taruna Cahaya Muda</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .bg-pattern {
            background-image: radial-gradient(#cbd5e1 0.8px, transparent 0.8px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased relative overflow-x-hidden selection:bg-blue-600 selection:text-white">

    <?php
    function loadImg($filename) {
        if (file_exists($filename)) {
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            return 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($filename));
        }
        return $filename;
    }

    $logo = loadImg('karangtaruna.jpeg');
    $img_gotongroyong = loadImg('gotongroyongkartar.jpeg');
    $img_gotongroyong2 = loadImg('gotongroyongkartar2.jpeg');
    $img_rapat = loadImg('rapatkartar.jpeg');
    $img_posyandu = loadImg('posyandukartar.jpeg');
    ?>

    <!-- Background Pattern -->
    <div class="fixed inset-0 bg-pattern opacity-30 pointer-events-none -z-10"></div>
    <div class="fixed -top-24 -left-20 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Navbar -->
    <nav class="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-3 group">
                <img src="<?= $logo; ?>" alt="Logo Cahaya Muda" class="w-11 h-11 object-contain group-hover:scale-105 transition rounded-xl">
                <div>
                    <span class="font-black text-slate-900 text-base block leading-tight">AGENDA KEGIATAN</span>
                    <span class="text-[10px] text-blue-600 font-bold uppercase tracking-widest block">Cahaya Muda • Njitengan Pogung</span>
                </div>
            </a>
            <div class="hidden md:flex items-center gap-8 text-xs font-bold text-slate-600">
                <a href="index.php" class="hover:text-blue-600 transition">Beranda</a>
                <a href="profil.php" class="hover:text-blue-600 transition">Profil</a>
                <a href="kegiatan.php" class="text-blue-600">Kegiatan</a>
                <a href="katalog.php" class="hover:text-blue-600 transition">Inventaris</a>
            </div>
            <a href="admin.php" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition flex items-center gap-2">
                <i class="fa-solid fa-gauge-high"></i> Admin
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="pt-32 pb-20 max-w-7xl mx-auto px-4 relative z-10">
        
        <div class="text-center max-w-3xl mx-auto mb-16">
            <span class="inline-block px-3.5 py-1 bg-blue-100/80 text-blue-700 font-extrabold text-[11px] rounded-full border border-blue-200 mb-3 shadow-sm">
                PROGRAM KERJA & DOKUMENTASI
            </span>
            <h1 class="text-3xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">Agenda & Galeri Kegiatan</h1>
            <p class="text-xs md:text-sm text-slate-500 leading-relaxed font-medium">Dokumentasi serta jadwal kegiatan sosial, kebudayaan, dan kerja bakti pemuda Njitengan Pogung.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            <!-- Kegiatan 1: Gotong Royong Masjid -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col sm:flex-row items-center gap-6 group">
                <div class="w-44 h-44 sm:w-48 sm:h-48 rounded-full overflow-hidden border-4 border-slate-100 shadow-md shrink-0 group-hover:scale-105 transition duration-300">
                    <img src="<?= $img_gotongroyong; ?>" alt="Gotong Royong Bersih Masjid" class="w-full h-full object-cover">
                </div>
                <div class="flex-1 text-center sm:text-left">
                    <span class="px-3 py-1 bg-emerald-100 text-emerald-700 font-bold text-[10px] rounded-full border border-emerald-200 inline-block mb-2">
                        Selesai
                    </span>
                    <h3 class="text-lg font-extrabold text-slate-900 mb-2 leading-snug">Gotong Royong Bersih Masjid 🧹</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-medium mb-4">
                        Aksi pembersihan area dalam masjid, penyapuan karpet, serta perawatan sarana ibadah bersama warga Njitengan.
                    </p>
                    <div class="flex items-center justify-center sm:justify-start gap-2 text-[11px] font-bold text-slate-400">
                        <i class="fa-regular fa-clock text-blue-500"></i>
                        <span>15 September 2026</span>
                    </div>
                </div>
            </div>

            <!-- Kegiatan 2: Pencarian Bambu Bendera -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col sm:flex-row items-center gap-6 group">
                <div class="w-44 h-44 sm:w-48 sm:h-48 rounded-full overflow-hidden border-4 border-slate-100 shadow-md shrink-0 group-hover:scale-105 transition duration-300">
                    <img src="<?= $img_gotongroyong2; ?>" alt="Penyiapan Bambu Bendera" class="w-full h-full object-cover">
                </div>
                <div class="flex-1 text-center sm:text-left">
                    <span class="px-3 py-1 bg-emerald-100 text-emerald-700 font-bold text-[10px] rounded-full border border-emerald-200 inline-block mb-2">
                        Selesai
                    </span>
                    <h3 class="text-lg font-extrabold text-slate-900 mb-2 leading-snug">Pencarian Bambu Tiang Bendera 🎋</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-medium mb-4">
                        Kerja bakti pemotongan dan penyiapan tiang bambu oleh pemuda Karang Taruna untuk pemasangan bendera desa.
                    </p>
                    <div class="flex items-center justify-center sm:justify-start gap-2 text-[11px] font-bold text-slate-400">
                        <i class="fa-regular fa-clock text-blue-500"></i>
                        <span>25 September 2026</span>
                    </div>
                </div>
            </div>

            <!-- Kegiatan 3: Rapat Rutin -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col sm:flex-row items-center gap-6 group">
                <div class="w-44 h-44 sm:w-48 sm:h-48 rounded-full overflow-hidden border-4 border-slate-100 shadow-md shrink-0 group-hover:scale-105 transition duration-300">
                    <img src="<?= $img_rapat; ?>" alt="Rapat Pemuda" class="w-full h-full object-cover">
                </div>
                <div class="flex-1 text-center sm:text-left">
                    <span class="px-3 py-1 bg-blue-100 text-blue-700 font-bold text-[10px] rounded-full border border-blue-200 inline-block mb-2">
                        Rutin
                    </span>
                    <h3 class="text-lg font-extrabold text-slate-900 mb-2 leading-snug">Rapat Pleno & Evaluasi Bulanan 🤝</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-medium mb-4">
                        Musyawarah pengurus Karang Taruna pembahasan persiapan kegiatan desa dan evaluasi program kerja.
                    </p>
                    <div class="flex items-center justify-center sm:justify-start gap-2 text-[11px] font-bold text-slate-400">
                        <i class="fa-regular fa-clock text-blue-500"></i>
                        <span>Setiap Akhir Bulan</span>
                    </div>
                </div>
            </div>

            <!-- Kegiatan 4: Posyandu -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col sm:flex-row items-center gap-6 group">
                <div class="w-44 h-44 sm:w-48 sm:h-48 rounded-full overflow-hidden border-4 border-slate-100 shadow-md shrink-0 group-hover:scale-105 transition duration-300">
                    <img src="<?= $img_posyandu; ?>" alt="Posyandu" class="w-full h-full object-cover">
                </div>
                <div class="flex-1 text-center sm:text-left">
                    <span class="px-3 py-1 bg-violet-100 text-violet-700 font-bold text-[10px] rounded-full border border-violet-200 inline-block mb-2">
                        Sosial
                    </span>
                    <h3 class="text-lg font-extrabold text-slate-900 mb-2 leading-snug">Pendampingan Layanan Posyandu 👶</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-medium mb-4">
                        Bantuan kader muda dalam pelayanan penimbangan balita dan cek kesehatan warga desa.
                    </p>
                    <div class="flex items-center justify-center sm:justify-start gap-2 text-[11px] font-bold text-slate-400">
                        <i class="fa-regular fa-clock text-blue-500"></i>
                        <span>10 Oktober 2026</span>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!-- Footer dengan Credit Pembuat Website -->
    <footer class="py-10 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 text-center space-y-3">
            <p class="text-xs font-semibold text-slate-600">© <?= date('Y'); ?> Karang Taruna Cahaya Muda (Njitengan Pogung). All rights reserved.</p>
            <div class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full border border-slate-200/80">
                <i class="fa-solid fa-code text-blue-600 text-xs"></i>
                <span class="text-xs font-bold text-slate-700">Developed with ❤️ by <span class="text-blue-600 font-extrabold tracking-wide">NAILA ALZENA LEVIA</span></span>
            </div>
        </div>
    </footer>

</body>
</html>