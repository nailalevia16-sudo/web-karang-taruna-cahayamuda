<?php
include 'koneksi.php';

$pesan = '';
$tipe_pesan = '';

// 1. PROSES TAMBAH BARANG (INSERT)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_barang'])) {
    $kode_barang = trim($_POST['kode_barang'] ?? '');
    $nama_barang = trim($_POST['nama_barang'] ?? '');
    $kategori    = trim($_POST['kategori'] ?? '');
    $kondisi     = trim($_POST['kondisi'] ?? 'Baik');
    $stok        = intval($_POST['stok'] ?? 0);

    if (!empty($kode_barang) && !empty($nama_barang)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO barang (kode_barang, nama_barang, kategori, kondisi, stok) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$kode_barang, $nama_barang, $kategori, $kondisi, $stok]);
            $pesan = "Barang berhasil disimpan ke inventaris!";
            $tipe_pesan = "sukses";
        } catch (PDOException $e) {
            try {
                $stmt = $pdo->prepare("INSERT INTO barang (kode_barang, nama_barang, kategori, kondisi, jumlah) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$kode_barang, $nama_barang, $kategori, $kondisi, $stok]);
                $pesan = "Barang berhasil disimpan ke inventaris!";
                $tipe_pesan = "sukses";
            } catch (PDOException $ex) {
                $pesan = "Gagal menyimpan barang: " . $ex->getMessage();
                $tipe_pesan = "gagal";
            }
        }
    } else {
        $pesan = "Kode barang dan Nama barang wajib diisi!";
        $tipe_pesan = "gagal";
    }
}

// 2. PROSES HAPUS BARANG (DELETE)
if (isset($_GET['hapus'])) {
    $id_hapus = intval($_GET['hapus']);
    try {
        $stmt = $pdo->prepare("DELETE FROM barang WHERE id = ?");
        $stmt->execute([$id_hapus]);
        header("Location: admin.php?pesan=hapus_sukses");
        exit;
    } catch (PDOException $e) {
        $pesan = "Gagal menghapus barang.";
        $tipe_pesan = "gagal";
    }
}

// 3. PROSES SELESAI / KEMBALI PEMINJAMAN
if (isset($_GET['kembali'])) {
    $id_pinjam = intval($_GET['kembali']);
    try {
        $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'Dikembalikan' WHERE id = ?");
        $stmt->execute([$id_pinjam]);
        header("Location: admin.php?pesan=kembali_sukses");
        exit;
    } catch (Exception $e) {}
}

if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] === 'hapus_sukses') {
        $pesan = "Barang berhasil dihapus!";
        $tipe_pesan = "sukses";
    } elseif ($_GET['pesan'] === 'kembali_sukses') {
        $pesan = "Status peminjaman diperbarui: Barang telah dikembalikan!";
        $tipe_pesan = "sukses";
    }
}

// 4. AMBIL DATA BARANG & PEMINJAMAN
$cari = trim($_GET['cari'] ?? '');
if (!empty($cari)) {
    $stmt = $pdo->prepare("SELECT * FROM barang WHERE nama_barang LIKE ? OR kode_barang LIKE ? OR kategori LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$cari%", "%$cari%", "%$cari%"]);
    $data_barang = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $data_barang = $pdo->query("SELECT * FROM barang ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
}

// Ambil riwayat peminjaman dengan menggabungkan tabel barang
$data_peminjaman = [];
try {
    $data_peminjaman = $pdo->query("SELECT p.*, b.nama_barang, b.kode_barang FROM peminjaman p LEFT JOIN barang b ON p.barang_id = b.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

// HITUNG METRIK
$total_jenis = count($data_barang);
$total_stok = 0;
foreach ($data_barang as $b) {
    $val_stok = isset($b['stok']) ? $b['stok'] : (isset($b['jumlah']) ? $b['jumlah'] : 0);
    $total_stok += intval($val_stok);
}

$sedang_dipinjam = 0;
foreach ($data_peminjaman as $p) {
    if (($p['status'] ?? 'Dipinjam') === 'Dipinjam') {
        $sedang_dipinjam += intval($p['jumlah'] ?? 1);
    }
}

// Load Logo
function loadImg($filename) {
    if (file_exists($filename)) {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        return 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($filename));
    }
    return $filename;
}
$logo = loadImg('karangtaruna.jpeg');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Inventaris - Cahaya Muda</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Plus Jakarta Sans', sans-serif; } </style>
</head>
<body class="bg-slate-100 font-sans text-slate-800 min-h-screen p-4 md:p-8">

    <div class="max-w-7xl mx-auto space-y-6">

        <!-- Header Admin -->
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div class="flex items-center gap-4">
                <img src="<?= $logo; ?>" alt="Logo Cahaya Muda" class="w-12 h-12 object-contain rounded-xl">
                <div>
                    <h1 class="text-xl font-black text-slate-900">Inventaris Karang Taruna Cahaya Muda</h1>
                    <p class="text-xs text-slate-500 font-medium mt-0.5">Dashboard Internal Kelola Aset & Peminjaman Digital • Njitengan Pogung</p>
                </div>
            </div>

            <div class="flex flex-wrap items-center gap-2 text-xs">
                <a href="index.php" class="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition">
                    <i class="fa-solid fa-house mr-1"></i> Beranda
                </a>
                <a href="profil.php" class="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition">
                    <i class="fa-solid fa-users mr-1"></i> Profil
                </a>
                <a href="kegiatan.php" class="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition">
                    <i class="fa-solid fa-calendar mr-1"></i> Kegiatan
                </a>
                <a href="katalog.php" class="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition">
                    <i class="fa-solid fa-boxes-packing mr-1"></i> Katalog
                </a>
            </div>
        </div>

        <!-- Alert Pesan Status -->
        <?php if (!empty($pesan)): ?>
            <div class="p-4 rounded-2xl border text-xs font-bold flex items-center gap-3 <?= $tipe_pesan === 'sukses' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-rose-50 border-rose-200 text-rose-700'; ?>">
                <i class="fa-solid <?= $tipe_pesan === 'sukses' ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-rose-600'; ?> text-base"></i>
                <span><?= htmlspecialchars($pesan); ?></span>
            </div>
        <?php endif; ?>

        <!-- Metric Cards Realtime -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold tracking-wider text-slate-400 uppercase block mb-1">TOTAL JENIS BARANG</span>
                    <span class="text-2xl font-black text-slate-900"><?= $total_jenis; ?> Jenis</span>
                </div>
                <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
            </div>

            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold tracking-wider text-slate-400 uppercase block mb-1">TOTAL FISIK BARANG</span>
                    <span class="text-2xl font-black text-emerald-600"><?= $total_stok; ?> Unit</span>
                </div>
                <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-cubes"></i>
                </div>
            </div>

            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold tracking-wider text-slate-400 uppercase block mb-1">SEDANG DIPINJAM</span>
                    <span class="text-2xl font-black text-amber-500"><?= $sedang_dipinjam; ?> Unit</span>
                </div>
                <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-xl">
                    <i class="fa-solid fa-people-carry-box"></i>
                </div>
            </div>
        </div>

        <!-- Form & Table Area -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            <!-- Form Tambah Barang -->
            <div class="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm h-fit space-y-4">
                <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <i class="fa-solid fa-circle-plus text-blue-600"></i> Tambah Barang Inventaris
                </h2>

                <form action="admin.php" method="POST" class="space-y-3 text-xs">
                    <div>
                        <label class="font-bold text-slate-700 block mb-1">Kode Barang</label>
                        <input type="text" name="kode_barang" required placeholder="Contoh: BRG-001" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                    </div>
                    <div>
                        <label class="font-bold text-slate-700 block mb-1">Nama Barang</label>
                        <input type="text" name="nama_barang" required placeholder="Contoh: Sound System Portable" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                    </div>
                    <div>
                        <label class="font-bold text-slate-700 block mb-1">Kategori</label>
                        <input type="text" name="kategori" placeholder="Peralatan / Elektronik" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                    </div>
                    <div>
                        <label class="font-bold text-slate-700 block mb-1">Kondisi</label>
                        <select name="kondisi" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                            <option value="Baik">Baik</option>
                            <option value="Rusak Ringan">Rusak Ringan</option>
                            <option value="Rusak Berat">Rusak Berat</option>
                        </select>
                    </div>
                    <div>
                        <label class="font-bold text-slate-700 block mb-1">Jumlah Stok</label>
                        <input type="number" name="stok" min="1" value="1" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                    </div>
                    
                    <button type="submit" name="tambah_barang" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md shadow-blue-500/20 transition mt-2 flex items-center justify-center gap-2">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Barang
                    </button>
                </form>
            </div>

            <!-- Tabel Daftar Barang & Peminjaman -->
            <div class="lg:col-span-8 space-y-6">
                
                <!-- Pencarian Aset -->
                <form action="admin.php" method="GET" class="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-2">
                    <input type="text" name="cari" value="<?= htmlspecialchars($cari); ?>" placeholder="Cari nama atau kode barang..." class="w-full px-3 py-2 text-xs rounded-xl focus:outline-none bg-transparent">
                    <button type="submit" class="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5">
                        <i class="fa-solid fa-magnifying-glass"></i> Cari
                    </button>
                    <?php if(!empty($cari)): ?>
                        <a href="admin.php" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition">Reset</a>
                    <?php endif; ?>
                </form>

                <!-- Tabel Aset Inventaris -->
                <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
                    <div class="p-4 border-b border-slate-100 flex items-center justify-between">
                        <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800">Daftar Aset Inventaris</h3>
                        <span class="text-[10px] bg-slate-100 font-bold px-2.5 py-1 rounded-lg text-slate-600"><?= count($data_barang); ?> Item</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 text-slate-400 font-bold uppercase border-b border-slate-100">
                                <tr>
                                    <th class="p-4">Kode & Nama Barang</th>
                                    <th class="p-4">Kategori</th>
                                    <th class="p-4">Kondisi</th>
                                    <th class="p-4">Stok</th>
                                    <th class="p-4 text-right">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-600">
                                <?php if (empty($data_barang)): ?>
                                    <tr>
                                        <td colspan="5" class="p-8 text-center text-slate-400">Belum ada data barang ditemukan.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($data_barang as $row): 
                                        $val_stok = isset($row['stok']) ? $row['stok'] : (isset($row['jumlah']) ? $row['jumlah'] : 0);
                                    ?>
                                        <tr class="hover:bg-slate-50/80 transition">
                                            <td class="p-4">
                                                <span class="font-bold text-slate-900 block"><?= htmlspecialchars($row['nama_barang']); ?></span>
                                                <span class="text-[10px] font-mono text-slate-400"><?= htmlspecialchars($row['kode_barang']); ?></span>
                                            </td>
                                            <td class="p-4 font-medium"><?= htmlspecialchars($row['kategori'] ?: '-'); ?></td>
                                            <td class="p-4">
                                                <span class="px-2.5 py-1 rounded-md text-[10px] font-bold 
                                                    <?= $row['kondisi'] === 'Baik' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'; ?>">
                                                    <?= htmlspecialchars($row['kondisi']); ?>
                                                </span>
                                            </td>
                                            <td class="p-4 font-black text-blue-600"><?= htmlspecialchars($val_stok); ?> Unit</td>
                                            <td class="p-4 text-right">
                                                <a href="admin.php?hapus=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus barang ini?')" class="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition inline-block">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Tabel Riwayat & Status Peminjaman Warga -->
                <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
                    <div class="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                        <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800">
                            <i class="fa-solid fa-clipboard-list text-blue-600 mr-1.5"></i> Riwayat & Status Peminjaman Warga
                        </h3>
                        <span class="text-[10px] bg-blue-50 text-blue-700 font-bold px-2.5 py-1 rounded-lg border border-blue-100"><?= count($data_peminjaman); ?> Transaksi</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 text-slate-400 font-bold uppercase border-b border-slate-100">
                                <tr>
                                    <th class="p-4">Peminjam & Kontak</th>
                                    <th class="p-4">Barang Dipinjam</th>
                                    <th class="p-4">Jumlah & Tanggal</th>
                                    <th class="p-4">Status</th>
                                    <th class="p-4 text-right">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-600">
                                <?php if (empty($data_peminjaman)): ?>
                                    <tr>
                                        <td colspan="5" class="p-8 text-center text-slate-400">Belum ada riwayat peminjaman dari warga.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($data_peminjaman as $p): 
                                        $status = $p['status'] ?? 'Dipinjam';
                                    ?>
                                        <tr class="hover:bg-slate-50/80 transition">
                                            <td class="p-4">
                                                <span class="font-bold text-slate-900 block"><?= htmlspecialchars($p['nama_peminjam']); ?></span>
                                                <span class="text-[10px] text-slate-400"><i class="fa-brands fa-whatsapp text-emerald-600"></i> <?= htmlspecialchars($p['kontak']); ?></span>
                                            </td>
                                            <td class="p-4 font-semibold text-slate-800">
                                                <?= htmlspecialchars($p['nama_barang'] ?? 'Barang Dihapus'); ?>
                                            </td>
                                            <td class="p-4">
                                                <span class="font-bold text-blue-600 block"><?= htmlspecialchars($p['jumlah']); ?> Unit</span>
                                                <span class="text-[10px] text-slate-400"><?= htmlspecialchars($p['tanggal_pinjam']); ?></span>
                                            </td>
                                            <td class="p-4">
                                                <span class="px-2.5 py-1 rounded-md text-[10px] font-bold 
                                                    <?= $status === 'Dipinjam' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'; ?>">
                                                    <?= htmlspecialchars($status); ?>
                                                </span>
                                            </td>
                                            <td class="p-4 text-right">
                                                <?php if ($status === 'Dipinjam'): ?>
                                                    <a href="admin.php?kembali=<?= $p['id']; ?>" onclick="return confirm('Konfirmasi barang ini sudah dikembalikan oleh warga?')" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition inline-flex items-center gap-1 shadow-sm">
                                                        <i class="fa-solid fa-check"></i> Selesai
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-[10px] text-slate-400 font-bold">Selesai</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </div>

        <!-- Footer Credit -->
        <div class="pt-6 border-t border-slate-200/80 text-center">
            <p class="text-xs text-slate-500 font-medium">
                © <?= date('Y'); ?> Karang Taruna Cahaya Muda • Developed with ❤️ by <span class="text-blue-600 font-extrabold">NAILA ALZENA LEVIA</span>
            </p>
        </div>

    </div>

</body>
</html>