<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karang Taruna Cahaya Muda - Portal Resmi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .bg-pattern {
            background-image: radial-gradient(#cbd5e1 0.8px, transparent 0.8px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased relative overflow-x-hidden selection:bg-blue-600 selection:text-white">

    <?php
    // Fungsi pembuka gambar lokal otomatis dengan Base64
    function loadImg($filename) {
        if (file_exists($filename)) {
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            return 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($filename));
        }
        return $filename;
    }

    $logo = loadImg('karangtaruna.jpeg');
    $profil_hero = loadImg('profilkartar.jpeg');
    $img_gotongroyong = loadImg('gotongroyongkartar.jpeg');
    $img_rapat = loadImg('rapatkartar.jpeg');
    $img_posyandu = loadImg('posyandukartar.jpeg');
    ?>

    <!-- Background Pattern & Ambient Glow -->
    <div class="fixed inset-0 bg-pattern opacity-30 pointer-events-none -z-10"></div>
    <div class="fixed -top-24 -left-20 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none -z-10"></div>
    <div class="fixed top-1/3 -right-20 w-96 h-96 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Navbar Glassmorphism -->
    <nav class="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <a href="index.php" class="flex items-center gap-3 group">
                    <img src="<?= $logo; ?>" alt="Logo Cahaya Muda" class="w-11 h-11 object-contain group-hover:scale-105 transition rounded-xl">
                    <div>
                        <span class="font-black text-slate-900 text-base block leading-tight">KARANG TARUNA</span>
                        <span class="text-[10px] text-blue-600 font-bold uppercase tracking-widest block">Cahaya Muda • Njitengan Pogung</span>
                    </div>
                </a>

                <div class="hidden md:flex items-center gap-8 text-xs font-bold text-slate-600">
                    <a href="index.php" class="text-blue-600">Beranda</a>
                    <a href="profil.php" class="hover:text-blue-600 transition">Profil</a>
                    <a href="kegiatan.php" class="hover:text-blue-600 transition">Kegiatan</a>
                    <a href="katalog.php" class="hover:text-blue-600 transition">Inventaris</a>
                </div>

                <div>
                    <a href="admin.php" class="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition flex items-center gap-2">
                        <i class="fa-solid fa-gauge-high"></i> Dashboard Admin
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="pt-32 pb-16 relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                
                <div class="lg:col-span-7 space-y-6 text-center lg:text-left">
                    <span class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100/80 border border-blue-200 text-blue-700 text-xs font-extrabold shadow-sm">
                        <i class="fa-solid fa-sparkles text-blue-600"></i> PORTAL RESMI KEPEMUDAAN & LAYANAN DESA
                    </span>
                    <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
                        Inovasi, Aksi, & Pengabdian <br>
                        <span class="bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent">Karang Taruna Cahaya Muda</span>
                    </h1>
                    <p class="text-sm sm:text-base text-slate-600 leading-relaxed font-medium max-w-2xl mx-auto lg:mx-0">
                        Wadah kolaborasi pemuda Njitengan Pogung untuk mendorong kemajuan sosial, kreativitas, ekonomi, serta keterbukaan peminjaman fasilitas inventaris masyarakat.
                    </p>

                    <div class="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
                        <a href="katalog.php" class="px-7 py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-xl shadow-blue-500/25 transition flex items-center gap-2">
                            <i class="fa-solid fa-boxes-packing"></i> Cek Katalog Inventaris
                        </a>
                        <a href="profil.php" class="px-7 py-3.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200/80 text-xs font-bold rounded-2xl shadow-sm transition">
                            Pelajari Profil Organisasi
                        </a>
                    </div>

                    <!-- Counter Stats -->
                    <div class="pt-8 border-t border-slate-200/80 grid grid-cols-3 gap-4">
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-slate-900 block">50+</span>
                            <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Pemuda Aktif</span>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-blue-600 block">12+</span>
                            <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Program Kerja</span>
                        </div>
                        <div>
                            <span class="text-2xl sm:text-3xl font-black text-emerald-600 block">100%</span>
                            <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Layanan Warga</span>
                        </div>
                    </div>
                </div>

                <!-- Gambar Utama Profil Kartar -->
                <div class="lg:col-span-5 relative">
                    <div class="relative mx-auto max-w-md lg:max-w-none">
                        <div class="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl blur-xl opacity-30"></div>
                        <div class="relative bg-white p-3 rounded-3xl border border-slate-200/80 shadow-2xl overflow-hidden">
                            <img src="<?= $profil_hero; ?>" 
                                 alt="Kegiatan Karang Taruna Cahaya Muda" 
                                 class="w-full h-80 lg:h-[420px] object-cover rounded-2xl">
                            
                            <div class="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-md p-4 rounded-2xl border border-white/60 shadow-lg flex items-center gap-4">
                                <img src="<?= $logo; ?>" alt="Logo Mini" class="w-12 h-12 object-contain rounded-xl bg-white p-1 border border-slate-100">
                                <div>
                                    <h4 class="text-xs font-black text-slate-900">Karang Taruna Cahaya Muda</h4>
                                    <p class="text-[10px] text-blue-600 font-bold">Njitengan Pogung, Cawas</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Visual Feature Cards dengan Foto Asli Kamu -->
    <section class="py-16 bg-white border-y border-slate-200/80">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-xl mx-auto mb-12">
                <span class="text-blue-600 text-xs font-extrabold uppercase tracking-widest block mb-1">Layanan & Pilar</span>
                <h2 class="text-2xl md:text-3xl font-black text-slate-900">Fokus Utama Kegiatan</h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                
                <!-- Card 1 -->
                <div class="bg-slate-50/70 rounded-3xl border border-slate-200/80 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition duration-300 group">
                    <div class="h-48 overflow-hidden relative">
                        <img src="<?= $img_rapat; ?>" 
                             alt="Pemberdayaan Pemuda" 
                             class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                        <span class="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-md text-blue-600 font-extrabold text-[10px] rounded-full border border-white/60 shadow-sm">
                            Kepemimpinan
                        </span>
                    </div>
                    <div class="p-6">
                        <h3 class="text-base font-extrabold text-slate-900 mb-2">Musyawarah & Kepemimpinan</h3>
                        <p class="text-xs text-slate-500 leading-relaxed font-medium">
                            Forum konsolidasi dan koordinasi rutin pemuda dalam merencanakan program kerja yang berdampak bagi masyarakat.
                        </p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-slate-50/70 rounded-3xl border border-slate-200/80 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition duration-300 group">
                    <div class="h-48 overflow-hidden relative">
                        <img src="<?= $img_gotongroyong; ?>" 
                             alt="Program & Kegiatan" 
                             class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                        <span class="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-md text-indigo-600 font-extrabold text-[10px] rounded-full border border-white/60 shadow-sm">
                            Gotong Royong
                        </span>
                    </div>
                    <div class="p-6">
                        <h3 class="text-base font-extrabold text-slate-900 mb-2">Kerja Bakti & Sosial</h3>
                        <p class="text-xs text-slate-500 leading-relaxed font-medium">
                            Aksi gotong royong pemuda dalam menjaga kebersihan lingkungan desa serta solidaritas kemasyarakatan.
                        </p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-slate-50/70 rounded-3xl border border-slate-200/80 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition duration-300 group">
                    <div class="h-48 overflow-hidden relative">
                        <img src="<?= $img_posyandu; ?>" 
                             alt="Layanan Masyarakat" 
                             class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                        <span class="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-md text-emerald-600 font-extrabold text-[10px] rounded-full border border-white/60 shadow-sm">
                            Kesehatan Warga
                        </span>
                    </div>
                    <div class="p-6">
                        <h3 class="text-base font-extrabold text-slate-900 mb-2">Pendampingan Posyandu</h3>
                        <p class="text-xs text-slate-500 leading-relaxed font-medium">
                            Partisipasi aktif pemudi Karang Taruna dalam mendukung kegiatan kesehatan balita dan lansia di desa.
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer dengan Credit Pembuat Website -->
    <footer class="py-10 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 text-center space-y-3">
            <p class="text-xs font-semibold text-slate-600">© <?= date('Y'); ?> Karang Taruna Cahaya Muda (Njitengan Pogung). All rights reserved.</p>
            <div class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full border border-slate-200/80">
                <i class="fa-solid fa-code text-blue-600 text-xs"></i>
                <span class="text-xs font-bold text-slate-700">Developed with ❤️ by <span class="text-blue-600 font-extrabold tracking-wide">NAILA ALZENA LEVIA</span></span>
            </div>
        </div>
    </footer>

</body>
</html>