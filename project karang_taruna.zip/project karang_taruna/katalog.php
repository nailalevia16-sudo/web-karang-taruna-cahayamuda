<?php
include 'koneksi.php';

$barang = [];
if (isset($pdo)) {
    try {
        $barang = $pdo->query("SELECT * FROM barang ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {}
}

function loadImg($filename) {
    if (file_exists($filename)) {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        return 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($filename));
    }
    return $filename;
}
$logo = loadImg('karangtaruna.jpeg');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Inventaris - Karang Taruna Cahaya Muda</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .bg-pattern {
            background-image: radial-gradient(#cbd5e1 0.8px, transparent 0.8px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased relative overflow-x-hidden selection:bg-blue-600 selection:text-white">

    <!-- Background Pattern -->
    <div class="fixed inset-0 bg-pattern opacity-30 pointer-events-none -z-10"></div>
    <div class="fixed -top-24 -left-20 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Navbar -->
    <nav class="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-3 group">
                <img src="<?= $logo; ?>" alt="Logo Cahaya Muda" class="w-11 h-11 object-contain group-hover:scale-105 transition rounded-xl">
                <div>
                    <span class="font-black text-slate-900 text-base block leading-tight">KATALOG INVENTARIS</span>
                    <span class="text-[10px] text-blue-600 font-bold uppercase tracking-widest block">Cahaya Muda • Njitengan Pogung</span>
                </div>
            </a>
            <div class="hidden md:flex items-center gap-8 text-xs font-bold text-slate-600">
                <a href="index.php" class="hover:text-blue-600 transition">Beranda</a>
                <a href="profil.php" class="hover:text-blue-600 transition">Profil</a>
                <a href="kegiatan.php" class="hover:text-blue-600 transition">Kegiatan</a>
                <a href="katalog.php" class="text-blue-600">Inventaris</a>
            </div>
            <a href="admin.php" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition flex items-center gap-2">
                <i class="fa-solid fa-gauge-high"></i> Admin
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="pt-32 pb-20 max-w-7xl mx-auto px-4 relative z-10">
        
        <div class="text-center max-w-2xl mx-auto mb-12">
            <span class="inline-block px-3.5 py-1 bg-blue-100/80 text-blue-700 font-extrabold text-[11px] rounded-full border border-blue-200 mb-3 shadow-sm">
                LAYANAN PEMINJAMAN WARGA
            </span>
            <h1 class="text-3xl font-black text-slate-900 mb-2">Katalog Barang & Aset Desa</h1>
            <p class="text-xs text-slate-500 font-medium">Silakan pilih barang yang ingin dipinjam dan klik tombol ajukan peminjaman.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if (empty($barang)): ?>
                <div class="col-span-full text-center py-12 bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200 text-slate-400 text-xs shadow-sm">
                    Belum ada data barang. Silakan tambahkan data terlebih dahulu lewat Dashboard Admin.
                </div>
            <?php else: ?>
                <?php foreach ($barang as $b): 
                    $stok_val = isset($b['stok']) ? $b['stok'] : (isset($b['jumlah']) ? $b['jumlah'] : 0);
                ?>
                <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between mb-4">
                            <span class="px-3 py-1 bg-blue-50 text-blue-600 border border-blue-100 text-[10px] font-bold rounded-lg">
                                <?= htmlspecialchars($b['kategori'] ?? 'Umum'); ?>
                            </span>
                            <span class="text-[10px] font-mono font-bold text-slate-400"><?= htmlspecialchars($b['kode_barang'] ?? '-'); ?></span>
                        </div>
                        <h3 class="text-base font-extrabold text-slate-900 mb-1 capitalize"><?= htmlspecialchars($b['nama_barang'] ?? 'Barang'); ?></h3>
                        <p class="text-xs text-slate-500 mb-6">Kondisi: <span class="text-slate-700 font-bold"><?= htmlspecialchars($b['kondisi'] ?? 'Baik'); ?></span></p>
                    </div>
                    
                    <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
                        <div>
                            <span class="text-[10px] text-slate-400 font-semibold block">Stok Tersedia</span>
                            <span class="text-sm font-black text-blue-600"><?= htmlspecialchars($stok_val); ?> Unit</span>
                        </div>
                        <!-- Tombol diarahkan langsung ke peminjaman.php dengan membawa ID barang -->
                        <a href="peminjaman.php?id=<?= $b['id']; ?>" class="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-blue-500/20 flex items-center gap-1.5">
                            <i class="fa-solid fa-hand-holding"></i> Ajukan Pinjam
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="py-10 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 text-center space-y-3">
            <p class="text-xs font-semibold text-slate-600">© <?= date('Y'); ?> Karang Taruna Cahaya Muda (Njitengan Pogung). All rights reserved.</p>
            <div class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full border border-slate-200/80">
                <i class="fa-solid fa-code text-blue-600 text-xs"></i>
                <span class="text-xs font-bold text-slate-700">Developed with ❤️ by <span class="text-blue-600 font-extrabold tracking-wide">NAILA ALZENA LEVIA</span></span>
            </div>
        </div>
    </footer>

</body>
</html>