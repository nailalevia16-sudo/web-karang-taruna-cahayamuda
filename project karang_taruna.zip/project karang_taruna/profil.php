<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Karang Taruna Cahaya Muda</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .bg-pattern {
            background-image: radial-gradient(#cbd5e1 0.8px, transparent 0.8px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased relative overflow-x-hidden selection:bg-blue-600 selection:text-white">

    <?php
    // Buka file logo dengan aman via Base64 jika ada
    $logo_src = 'karangtaruna.jpeg';
    if (file_exists('karangtaruna.jpeg')) {
        $logo_src = 'data:image/jpeg;base64,' . base64_encode(file_get_contents('karangtaruna.jpeg'));
    } elseif (file_exists('karangtaruna.jpg')) {
        $logo_src = 'karangtaruna.jpg';
    }
    ?>

    <!-- Background Decorative Glows & Pattern -->
    <div class="fixed inset-0 bg-pattern opacity-40 pointer-events-none -z-10"></div>
    <div class="fixed -top-24 -left-20 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl pointer-events-none -z-10"></div>
    <div class="fixed top-1/3 -right-20 w-96 h-96 bg-indigo-400/20 rounded-full blur-3xl pointer-events-none -z-10"></div>
    <div class="fixed -bottom-20 left-1/3 w-96 h-96 bg-violet-400/15 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Navbar Glassmorphism Modern -->
    <nav class="fixed top-0 inset-x-0 z-50 bg-white/70 backdrop-blur-lg border-b border-slate-200/80 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-3 group">
                <img src="<?= $logo_src; ?>" alt="Logo Cahaya Muda" class="w-11 h-11 object-contain group-hover:scale-105 transition rounded-xl">
                <div>
                    <span class="font-black text-slate-900 text-base block leading-tight">KARANG TARUNA</span>
                    <span class="text-[10px] text-blue-600 font-bold uppercase tracking-widest block">Cahaya Muda • Njitengan Pogung</span>
                </div>
            </a>
            <div class="hidden md:flex items-center gap-8 text-xs font-bold text-slate-600">
                <a href="index.php" class="hover:text-blue-600 transition">Beranda</a>
                <a href="profil.php" class="text-blue-600">Profil</a>
                <a href="kegiatan.php" class="hover:text-blue-600 transition">Kegiatan</a>
                <a href="katalog.php" class="hover:text-blue-600 transition">Inventaris</a>
            </div>
            <a href="admin.php" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition flex items-center gap-2">
                <i class="fa-solid fa-gauge-high"></i> Admin
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="pt-32 pb-20 max-w-7xl mx-auto px-4 relative z-10">
        
        <!-- Header Banner -->
        <div class="text-center max-w-3xl mx-auto mb-16">
            <div class="inline-flex items-center justify-center p-3 bg-white/80 backdrop-blur-md rounded-3xl mb-4 border border-slate-200/80 shadow-md">
                <img src="<?= $logo_src; ?>" alt="Logo Cahaya Muda" class="w-16 h-16 object-contain">
            </div>
            <br>
            <span class="inline-block px-3.5 py-1 bg-blue-100/80 text-blue-700 font-extrabold text-[11px] rounded-full border border-blue-200 mb-3 shadow-sm">
                STUKTUR & IDENTITAS
            </span>
            <h1 class="text-3xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">Profil & Struktur Organisasi</h1>
            <p class="text-xs md:text-sm text-slate-600 leading-relaxed font-medium">Mengenal lebih dekat visi, misi, dan susunan kepengurusan Karang Taruna Cahaya Muda Njitengan Pogung.</p>
        </div>

        <!-- Visi & Misi Cards (Glassmorphism Light) -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
            <div class="p-8 rounded-3xl bg-white/80 backdrop-blur-md border border-slate-200/80 shadow-sm hover:shadow-xl hover:border-blue-300 transition duration-300">
                <div class="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center text-xl mb-6 shadow-md shadow-blue-500/30">
                    <i class="fa-solid fa-eye"></i>
                </div>
                <h3 class="text-xl font-extrabold text-slate-900 mb-3">Visi Organisasi</h3>
                <p class="text-xs text-slate-600 leading-relaxed font-medium">
                    Terwujudnya pemuda pemudi Karang Taruna Cahaya Muda yang bertakwa, berakhlak mulia, inovatif, serta mandiri dalam membangun kesejahteraan sosial di lingkungan Njitengan Pogung.
                </p>
            </div>

            <div class="p-8 rounded-3xl bg-white/80 backdrop-blur-md border border-slate-200/80 shadow-sm hover:shadow-xl hover:border-indigo-300 transition duration-300">
                <div class="w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center text-xl mb-6 shadow-md shadow-indigo-500/30">
                    <i class="fa-solid fa-bullseye"></i>
                </div>
                <h3 class="text-xl font-extrabold text-slate-900 mb-3">Misi Organisasi</h3>
                <ul class="text-xs text-slate-600 space-y-3 font-medium">
                    <li class="flex items-start gap-2.5">
                        <i class="fa-solid fa-circle-check text-indigo-600 mt-0.5"></i>
                        <span>Menumbuhkan rasa kebersamaan dan gotong royong antar warga Pogung.</span>
                    </li>
                    <li class="flex items-start gap-2.5">
                        <i class="fa-solid fa-circle-check text-indigo-600 mt-0.5"></i>
                        <span>Mengembangkan potensi minat, bakat, dan kewirausahaan pemuda.</span>
                    </li>
                    <li class="flex items-start gap-2.5">
                        <i class="fa-solid fa-circle-check text-indigo-600 mt-0.5"></i>
                        <span>Mengelola aset & inventaris organisasi secara transparan dan akuntabel.</span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Pengurus Inti Section -->
        <div class="text-center max-w-xl mx-auto mb-12">
            <span class="text-blue-600 text-xs font-extrabold uppercase tracking-widest block mb-1">Kepengurusan</span>
            <h2 class="text-2xl md:text-3xl font-black text-slate-900">Pengurus Inti Organisasi</h2>
            <p class="text-xs text-slate-500 mt-1">Daftar pengurus inti yang mengabdi dan mengelola kegiatan kepemudaan.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <!-- Ketua -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 transition duration-300 text-center relative overflow-hidden group">
                <div class="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
                <div class="w-20 h-20 bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-2xl rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/30 group-hover:scale-105 transition">
                    BA
                </div>
                <h4 class="text-base font-extrabold text-slate-900 mb-1">Bayu Aji</h4>
                <span class="inline-block px-3 py-1 bg-blue-50 text-blue-700 font-bold text-[11px] rounded-full border border-blue-100">
                    Ketua Karang Taruna
                </span>
                <p class="text-[11px] text-slate-400 mt-3 font-medium">Penanggung Jawab Utama & Koordinator Organisasi</p>
            </div>

            <!-- Wakil Ketua -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 transition duration-300 text-center relative overflow-hidden group">
                <div class="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-indigo-600 to-violet-600"></div>
                <div class="w-20 h-20 bg-gradient-to-tr from-indigo-600 to-violet-600 text-white font-black text-2xl rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-500/30 group-hover:scale-105 transition">
                    RS
                </div>
                <h4 class="text-base font-extrabold text-slate-900 mb-1">Riski</h4>
                <span class="inline-block px-3 py-1 bg-indigo-50 text-indigo-700 font-bold text-[11px] rounded-full border border-indigo-100">
                    Wakil Ketua
                </span>
                <p class="text-[11px] text-slate-400 mt-3 font-medium">Pendamping Ketua & Pengawas Operasional Program</p>
            </div>

            <!-- Sekretaris -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 transition duration-300 text-center relative overflow-hidden group">
                <div class="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-violet-600 to-pink-600"></div>
                <div class="w-20 h-20 bg-gradient-to-tr from-violet-600 to-pink-600 text-white font-black text-2xl rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-violet-500/30 group-hover:scale-105 transition">
                    TR
                </div>
                <h4 class="text-base font-extrabold text-slate-900 mb-1">Tiara</h4>
                <span class="inline-block px-3 py-1 bg-violet-50 text-violet-700 font-bold text-[11px] rounded-full border border-violet-100">
                    Sekretaris
                </span>
                <p class="text-[11px] text-slate-400 mt-3 font-medium">Pengelola Administrasi, Persuratan & Arsip</p>
            </div>

            <!-- Bendahara -->
            <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 transition duration-300 text-center relative overflow-hidden group">
                <div class="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-emerald-500 to-teal-600"></div>
                <div class="w-20 h-20 bg-gradient-to-tr from-emerald-500 to-teal-600 text-white font-black text-2xl rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/30 group-hover:scale-105 transition">
                    LN
                </div>
                <h4 class="text-base font-extrabold text-slate-900 mb-1">Linda</h4>
                <span class="inline-block px-3 py-1 bg-emerald-50 text-emerald-700 font-bold text-[11px] rounded-full border border-emerald-100">
                    Bendahara
                </span>
                <p class="text-[11px] text-slate-400 mt-3 font-medium">Pengelola Keuangan & Laporan Anggaran Kas</p>
            </div>

        </div>

    </div>

    <footer class="py-8 bg-white/80 backdrop-blur-md border-t border-slate-200 text-center text-xs text-slate-500 relative z-10">
        <p>© <?= date('Y'); ?> Karang Taruna Cahaya Muda (Njitengan Pogung). All rights reserved.</p>
    </footer>

</body>
</html>