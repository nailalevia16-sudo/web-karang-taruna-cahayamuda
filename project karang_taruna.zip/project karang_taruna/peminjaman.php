<?php
include 'koneksi.php';

$pesan = '';
$tipe_pesan = '';

// Proses Simpan Peminjaman
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proses_pinjam'])) {
    $barang_id      = intval($_POST['barang_id'] ?? 0);
    $nama_peminjam  = trim($_POST['nama_peminjam'] ?? '');
    $kontak         = trim($_POST['kontak'] ?? '');
    $jumlah_pinjam  = intval($_POST['jumlah_pinjam'] ?? 1);
    $tanggal_pinjam = trim($_POST['tanggal_pinjam'] ?? date('Y-m-d'));

    if ($barang_id > 0 && !empty($nama_peminjam)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO peminjaman (barang_id, nama_peminjam, kontak, jumlah, tanggal_pinjam, status) VALUES (?, ?, ?, ?, ?, 'Dipinjam')");
            $stmt->execute([$barang_id, $nama_peminjam, $kontak, $jumlah_pinjam, $tanggal_pinjam]);
            
            $pesan = "Peminjaman berhasil diajukan dan dicatat!";
            $tipe_pesan = "sukses";
        } catch (Exception $e) {
            $pesan = "Gagal memproses peminjaman: " . $e->getMessage();
            $tipe_pesan = "gagal";
        }
    } else {
        $pesan = "Silakan pilih barang dan isi nama peminjam dengan benar!";
        $tipe_pesan = "gagal";
    }
}

// Ambil Data Barang
$barang_list = [];
try {
    $barang_list = $pdo->query("SELECT * FROM barang ORDER BY nama_barang ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

$selected_id = intval($_GET['id'] ?? 0);

// Load Logo
function loadImg($filename) {
    if (file_exists($filename)) {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        return 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($filename));
    }
    return $filename;
}
$logo = loadImg('karangtaruna.jpeg');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Peminjaman Aset - Cahaya Muda</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style> 
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .bg-pattern {
            background-image: radial-gradient(#cbd5e1 0.8px, transparent 0.8px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased relative min-h-screen flex flex-col justify-between selection:bg-blue-600 selection:text-white">

    <!-- Background Pattern -->
    <div class="fixed inset-0 bg-pattern opacity-30 pointer-events-none -z-10"></div>
    <div class="fixed -top-24 -left-20 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none -z-10"></div>

    <!-- Navbar -->
    <nav class="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/80 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-3 group">
                <img src="<?= $logo; ?>" alt="Logo Cahaya Muda" class="w-11 h-11 object-contain group-hover:scale-105 transition rounded-xl">
                <div>
                    <span class="font-black text-slate-900 text-base block leading-tight">FORM PEMINJAMAN</span>
                    <span class="text-[10px] text-blue-600 font-bold uppercase tracking-widest block">Cahaya Muda • Njitengan Pogung</span>
                </div>
            </a>
            <div class="hidden md:flex items-center gap-8 text-xs font-bold text-slate-600">
                <a href="index.php" class="hover:text-blue-600 transition">Beranda</a>
                <a href="profil.php" class="hover:text-blue-600 transition">Profil</a>
                <a href="kegiatan.php" class="hover:text-blue-600 transition">Kegiatan</a>
                <a href="katalog.php" class="text-blue-600">Inventaris</a>
            </div>
            <a href="admin.php" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 transition flex items-center gap-2">
                <i class="fa-solid fa-gauge-high"></i> Admin
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="pt-32 pb-20 max-w-xl mx-auto px-4 w-full relative z-10 flex-grow">
        
        <div class="text-center mb-8">
            <span class="inline-block px-3.5 py-1 bg-blue-100/80 text-blue-700 font-extrabold text-[11px] rounded-full border border-blue-200 mb-2 shadow-sm">
                LAYANAN DIGITAL WARGA
            </span>
            <h1 class="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">Formulir Peminjaman Aset</h1>
            <p class="text-xs text-slate-500 mt-1">Lengkapi data di bawah untuk mengajukan peminjaman peralatan desa.</p>
        </div>

        <?php if (!empty($pesan)): ?>
            <div class="mb-6 p-4 rounded-2xl border text-xs font-bold flex items-center gap-3 <?= $tipe_pesan === 'sukses' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-rose-50 border-rose-200 text-rose-700'; ?>">
                <i class="fa-solid <?= $tipe_pesan === 'sukses' ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-rose-600'; ?> text-base"></i>
                <span><?= htmlspecialchars($pesan); ?></span>
            </div>
        <?php endif; ?>

        <div class="bg-white/90 backdrop-blur-md rounded-3xl border border-slate-200/80 p-6 md:p-8 shadow-sm">
            <form action="peminjaman.php" method="POST" class="space-y-4 text-xs">
                
                <div>
                    <label class="font-bold text-slate-700 block mb-1.5">Pilih Barang</label>
                    <select name="barang_id" required class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition font-medium">
                        <option value="">-- Pilih Barang yang Tersedia --</option>
                        <?php if (empty($barang_list)): ?>
                            <option value="" disabled>-- Belum ada data barang di database --</option>
                        <?php else: ?>
                            <?php foreach ($barang_list as $b): 
                                $stok_num = isset($b['stok']) ? $b['stok'] : (isset($b['jumlah']) ? $b['jumlah'] : 0);
                            ?>
                                <option value="<?= $b['id']; ?>" <?= ($selected_id === intval($b['id'])) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($b['nama_barang']); ?> (Stok: <?= $stok_num; ?> Unit)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="font-bold text-slate-700 block mb-1.5">Nama Peminjam</label>
                    <input type="text" name="nama_peminjam" required placeholder="Contoh: Budi Santoso" class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                </div>

                <div>
                    <label class="font-bold text-slate-700 block mb-1.5">Kontak / No. HP (WhatsApp)</label>
                    <input type="text" name="kontak" required placeholder="Contoh: 081234567890" class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                </div>

                <div>
                    <label class="font-bold text-slate-700 block mb-1.5">Jumlah Unit yang Dipinjam</label>
                    <input type="number" name="jumlah_pinjam" min="1" value="1" required class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                </div>

                <div>
                    <label class="font-bold text-slate-700 block mb-1.5">Tanggal Peminjaman</label>
                    <input type="date" name="tanggal_pinjam" value="<?= date('Y-m-d'); ?>" required class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 bg-slate-50 focus:bg-white transition">
                </div>

                <div class="pt-2">
                    <button type="submit" name="proses_pinjam" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 transition flex items-center justify-center gap-2">
                        <i class="fa-solid fa-paper-plane"></i> Proses Peminjaman
                    </button>
                </div>

            </form>
        </div>

    </div>

    <!-- Footer -->
    <footer class="py-8 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 text-center space-y-3">
            <p class="text-xs font-semibold text-slate-600">© <?= date('Y'); ?> Karang Taruna Cahaya Muda (Njitengan Pogung). All rights reserved.</p>
            <div class="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full border border-slate-200/80">
                <i class="fa-solid fa-code text-blue-600 text-xs"></i>
                <span class="text-xs font-bold text-slate-700">Developed with ❤️ by <span class="text-blue-600 font-extrabold tracking-wide">NAILA ALZENA LEVIA</span></span>
            </div>
        </div>
    </footer>

</body>
</html>