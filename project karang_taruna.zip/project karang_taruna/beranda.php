<?php
require 'koneksi.php';

// Ambil data barang yang siap dipinjam untuk katalog warga
$barang = $pdo->query("SELECT * FROM barang WHERE stok_tersedia > 0 ORDER BY id DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karang Taruna Tunas Muda - Official Website</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased">

    <!-- Navbar Sticky -->
    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/80">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center font-bold text-xl shadow-md shadow-indigo-200">
                        <i class="fa-solid fa-people-group"></i>
                    </div>
                    <div>
                        <span class="font-black text-slate-900 text-base block leading-tight">KARANG TARUNA</span>
                        <span class="text-[10px] text-indigo-600 font-bold uppercase tracking-widest block">Tunas Muda Mandiri</span>
                    </div>
                </div>
                <div class="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-600">
                    <a href="#beranda" class="hover:text-indigo-600 transition">Beranda</a>
                    <a href="#profil" class="hover:text-indigo-600 transition">Profil & Visi Misi</a>
                    <a href="#pengurus" class="hover:text-indigo-600 transition">Pengurus</a>
                    <a href="#katalog" class="hover:text-indigo-600 transition">Katalog Inventaris</a>
                </div>
                <div>
                    <a href="index.php" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-sm transition flex items-center gap-2">
                        <i class="fa-solid fa-lock"></i> Panel Admin
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="beranda" class="relative py-20 bg-gradient-to-b from-indigo-50/50 via-slate-50 to-slate-50 overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold mb-6">
                <i class="fa-solid fa-sparkles"></i> Wadah Kreativitas & Pengabdian Pemuda
            </span>
            <h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-tight mb-6">
                Membangun Desa Bersama <br><span class="text-indigo-600">Pemuda Karang Taruna</span>
            </h1>
            <p class="max-w-2xl mx-auto text-sm md:text-base text-slate-600 leading-relaxed mb-8">
                Pusat informasi kegiatan pemuda, pelayanan masyarakat, serta keterbukaan peminjaman fasilitas dan barang inventaris organisasi.
            </p>
            <div class="flex items-center justify-center gap-4">
                <a href="#katalog" class="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-200 transition">
                    Cek Inventaris Barang
                </a>
                <a href="#profil" class="px-6 py-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold rounded-xl transition">
                    Tentang Kami
                </a>
            </div>
        </div>
    </section>

    <!-- Profil & Visi Misi -->
    <section id="profil" class="py-16 bg-white border-y border-slate-200/80">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div>
                    <span class="text-xs font-bold uppercase tracking-widest text-indigo-600">Tentang Organisasi</span>
                    <h2 class="text-2xl font-bold text-slate-900 mt-2 mb-4">Visi & Misi Karang Taruna</h2>
                    <p class="text-xs text-slate-600 leading-relaxed mb-6">
                        Menjadi wadah pembinaan generasi muda yang kreatif, inovatif, bertakwa, serta aktif berpartisipasi dalam pembangunan kesejahteraan sosial masyarakat.
                    </p>
                    <div class="space-y-3">
                        <div class="flex items-start gap-3">
                            <div class="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                            <p class="text-xs text-slate-600">Mengembangkan potensi kepemimpinan dan kewirausahaan pemuda.</p>
                        </div>
                        <div class="flex items-start gap-3">
                            <div class="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                            <p class="text-xs text-slate-600">Mempererat tali silaturahmi serta gotong royong antar warga dan generasi muda.</p>
                        </div>
                        <div class="flex items-start gap-3">
                            <div class="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                            <p class="text-xs text-slate-600">Mengelola aset serta fasilitas sosial organisasi secara profesional dan transparan.</p>
                        </div>
                    </div>
                </div>
                <!-- Kartu Struktur Singkat -->
                <div class="grid grid-cols-2 gap-4">
                    <div class="p-5 bg-slate-50 rounded-2xl border border-slate-200/80">
                        <div class="text-3xl font-black text-indigo-600 mb-1">50+</div>
                        <div class="text-xs font-bold text-slate-800">Anggota Aktif</div>
                        <div class="text-[10px] text-slate-500 mt-1">Pemuda pemudi pemudi terdaftar</div>
                    </div>
                    <div class="p-5 bg-slate-50 rounded-2xl border border-slate-200/80">
                        <div class="text-3xl font-black text-emerald-600 mb-1">12+</div>
                        <div class="text-xs font-bold text-slate-800">Program Kerja</div>
                        <div class="text-[10px] text-slate-500 mt-1">Terlaksana sepanjang tahun</div>
                    </div>
                    <div class="p-5 bg-slate-50 rounded-2xl border border-slate-200/80 col-span-2">
                        <div class="text-3xl font-black text-slate-900 mb-1">100%</div>
                        <div class="text-xs font-bold text-slate-800">Layanan Gratis Masyarakat</div>
                        <div class="text-[10px] text-slate-500 mt-1">Fasilitas inventaris dapat dipinjam oleh warga</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Katalog Inventaris untuk Warga -->
    <section id="katalog" class="py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-2xl mx-auto mb-12">
                <span class="text-xs font-bold uppercase tracking-widest text-indigo-600">Fasilitas & Aset</span>
                <h2 class="text-2xl font-bold text-slate-900 mt-1">Katalog Barang Peminjaman Warga</h2>
                <p class="text-xs text-slate-500 mt-2">Daftar barang inventaris yang tersedia dan bisa dipinjam untuk kegiatan masyarakat.</p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if (empty($barang)): ?>
                    <div class="col-span-full text-center py-10 text-slate-400 text-xs">Belum ada barang tersedia saat ini.</div>
                <?php else: ?>
                    <?php foreach ($barang as $b): ?>
                    <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition">
                        <div class="flex items-center justify-between mb-4">
                            <span class="px-2.5 py-1 bg-indigo-50 text-indigo-700 font-bold text-[10px] rounded-lg">
                                <?= htmlspecialchars($b['kategori']); ?>
                            </span>
                            <span class="text-[10px] font-mono text-slate-400"><?= htmlspecialchars($b['kode_barang']); ?></span>
                        </div>
                        <h3 class="text-sm font-bold text-slate-800 mb-1"><?= htmlspecialchars($b['nama_barang']); ?></h3>
                        <p class="text-xs text-slate-500 mb-4">Kondisi: <span class="font-semibold text-slate-700"><?= $b['kondisi']; ?></span></p>
                        
                        <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
                            <div>
                                <span class="text-[10px] text-slate-400 block">Stok Tersedia</span>
                                <span class="text-sm font-black text-emerald-600"><?= $b['stok_tersedia']; ?> Unit</span>
                            </div>
                            <a href="index.php" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-[10px] font-bold rounded-lg transition">
                                Pinjam via Admin
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-slate-900 text-white py-8 text-xs border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p class="text-slate-400">© <?= date('Y'); ?> Karang Taruna Tunas Muda. Seluruh hak cipta dilindungi.</p>
        </div>
    </footer>

</body>
</html>