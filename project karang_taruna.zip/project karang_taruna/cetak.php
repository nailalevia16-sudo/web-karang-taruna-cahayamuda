<?php
require 'koneksi.php';

$barang = $pdo->query("SELECT * FROM barang ORDER BY nama_barang ASC")->fetchAll(PDO::FETCH_ASSOC);
$peminjaman = $pdo->query("SELECT p.*, b.nama_barang FROM peminjaman p JOIN barang b ON p.barang_id = b.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Inventaris Karang Taruna</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body class="bg-white p-8 text-slate-800 font-sans text-xs" onload="window.print()">

    <div class="max-w-4xl mx-auto">
        <!-- Header Laporan -->
        <div class="border-b-2 border-slate-800 pb-4 mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-xl font-bold uppercase tracking-wide text-slate-900">Laporan Aset & Inventaris</h1>
                <p class="text-slate-500">Karang Taruna - Sistem Inventarisasi Digital</p>
            </div>
            <div class="text-right text-slate-400">
                <div>Tanggal Cetak: <?= date('d/m/Y'); ?></div>
            </div>
        </div>

        <!-- Tabel Barang -->
        <h2 class="text-sm font-bold mb-2 uppercase tracking-wider text-slate-700">1. Ringkasan Aset</h2>
        <table class="w-full border-collapse border border-slate-300 mb-8 text-left">
            <thead>
                <tr class="bg-slate-100 text-slate-700">
                    <th class="border border-slate-300 p-2">Kode</th>
                    <th class="border border-slate-300 p-2">Nama Barang</th>
                    <th class="border border-slate-300 p-2">Kategori</th>
                    <th class="border border-slate-300 p-2">Kondisi</th>
                    <th class="border border-slate-300 p-2 text-center">Tersedia</th>
                    <th class="border border-slate-300 p-2 text-center">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($barang as $b): ?>
                <tr>
                    <td class="border border-slate-300 p-2 font-mono"><?= $b['kode_barang']; ?></td>
                    <td class="border border-slate-300 p-2 font-semibold"><?= $b['nama_barang']; ?></td>
                    <td class="border border-slate-300 p-2"><?= $b['kategori']; ?></td>
                    <td class="border border-slate-300 p-2"><?= $b['kondisi']; ?></td>
                    <td class="border border-slate-300 p-2 text-center font-bold"><?= $b['stok_tersedia']; ?></td>
                    <td class="border border-slate-300 p-2 text-center"><?= $b['total_stok']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Tabel Peminjaman -->
        <h2 class="text-sm font-bold mb-2 uppercase tracking-wider text-slate-700">2. Riwayat Transaksi Peminjaman</h2>
        <table class="w-full border-collapse border border-slate-300 text-left">
            <thead>
                <tr class="bg-slate-100 text-slate-700">
                    <th class="border border-slate-300 p-2">Peminjam</th>
                    <th class="border border-slate-300 p-2">Barang</th>
                    <th class="border border-slate-300 p-2">Jumlah</th>
                    <th class="border border-slate-300 p-2">Tgl Pinjam</th>
                    <th class="border border-slate-300 p-2">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peminjaman as $p): ?>
                <tr>
                    <td class="border border-slate-300 p-2 font-semibold"><?= $p['nama_peminjam']; ?></td>
                    <td class="border border-slate-300 p-2"><?= $p['nama_barang']; ?></td>
                    <td class="border border-slate-300 p-2"><?= $p['jumlah']; ?> Unit</td>
                    <td class="border border-slate-300 p-2"><?= $p['tgl_pinjam']; ?></td>
                    <td class="border border-slate-300 p-2 font-semibold"><?= $p['status']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>